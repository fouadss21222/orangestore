import { useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { useEffect, useState } from "react";

export default function App() {
  const products = useQuery(api.products.list) || [];
  const categories = ["minecraft", "discord", "telegram"];
  const [activeCategory, setActiveCategory] = useState("minecraft");

  // Parallax effect
  useEffect(() => {
    const handleScroll = () => {
      const header = document.querySelector('.parallax-header') as HTMLElement;
      if (header) {
        const scrolled = window.scrollY;
        header.style.backgroundPositionY = `${scrolled * 0.5}px`;
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-orange-100 to-orange-50">
      {/* Animated background patterns */}
      <div className="fixed inset-0 bg-[url('https://www.transparenttextures.com/patterns/diamond-upholstery.png')] opacity-5 pointer-events-none animate-slide"></div>
      <div className="fixed inset-0 bg-[url('https://www.transparenttextures.com/patterns/diagonal-striped-brick.png')] opacity-5 pointer-events-none animate-slide-reverse"></div>
      
      <header className="parallax-header relative h-[70vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-600 via-orange-500 to-orange-600"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/diamond-upholstery.png')] opacity-20"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/10 to-black/30"></div>
        
        {/* Animated shapes */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="floating-shape"></div>
          <div className="floating-shape delay-2"></div>
          <div className="floating-shape delay-4"></div>
        </div>
        
        <div className="relative z-10 text-center px-4 py-16 backdrop-blur-sm w-full">
          <div className="animate-glow">
            <h1 className="text-9xl font-bold text-white mb-8 animate-fade-in drop-shadow-2xl tracking-tight">
              Orange Store
            </h1>
            <p className="text-5xl text-orange-100 font-medium animate-slide-up tracking-wide">
              Minecraft | Discord | Telegram
            </p>
          </div>
        </div>
      </header>

      <nav className="bg-white/90 shadow-2xl py-8 sticky top-0 z-50 backdrop-blur-xl border-b border-orange-100">
        <div className="container mx-auto px-4">
          <div className="flex justify-center space-x-16">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`text-2xl font-bold px-12 py-6 rounded-2xl transition-all duration-500 transform hover:scale-110 ${
                  activeCategory === category
                    ? 'bg-gradient-to-br from-orange-500 to-orange-600 text-white shadow-2xl scale-110 hover:shadow-orange-500/25'
                    : 'text-gray-600 hover:text-orange-500 hover:bg-orange-50'
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-20">
        {categories.map((category) => (
          <section
            key={category}
            className={`transition-all duration-700 ${
              activeCategory === category ? 'opacity-100 transform translate-y-0' : 'hidden opacity-0 transform translate-y-10'
            }`}
          >
            <h2 className="text-7xl font-bold mb-20 text-orange-600 capitalize text-center">
              <span className="relative inline-block">
                {category} Products
                <span className="absolute -bottom-6 left-0 w-full h-2 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full"></span>
              </span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
              {products
                .filter((p) => p.category === category)
                .map((product, index) => (
                  <div
                    key={product._id}
                    className="group bg-white rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 hover:scale-105 overflow-hidden"
                    style={{
                      animationDelay: `${index * 150}ms`,
                      animation: 'fadeInUp 0.8s ease-out forwards',
                    }}
                  >
                    <div className="h-3 bg-gradient-to-r from-orange-400 via-orange-500 to-orange-600 transform origin-left transition-transform duration-500 group-hover:scale-x-110"></div>
                    <div className="relative p-12 overflow-hidden">
                      {/* Animated gradient background */}
                      <div className="absolute inset-0 bg-gradient-to-r from-orange-50 to-orange-100 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                      
                      <div className="relative z-10">
                        <h3 className="text-4xl font-bold mb-6 text-gray-800 group-hover:text-orange-600 transition-colors duration-300">
                          {product.name}
                        </h3>
                        <p className="text-xl text-gray-600 mb-10 min-h-[60px] group-hover:text-gray-700 transition-colors duration-300">
                          {product.description}
                        </p>
                        <div className="space-y-8">
                          <div className="flex items-center justify-between">
                            <span className="text-6xl text-orange-500 font-bold group-hover:scale-110 transition-transform duration-500 relative">
                              <span className="absolute -top-4 right-0 text-lg text-orange-400 font-normal">اسياسيل</span>
                              {product.price.toLocaleString()}
                            </span>
                          </div>
                          {product.duration && (
                            <div className="flex items-center text-gray-500 bg-orange-50 rounded-2xl p-6 group-hover:bg-orange-100 transition-all duration-300 transform group-hover:scale-105">
                              <svg
                                className="w-8 h-8 mr-4 text-orange-500"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                                />
                              </svg>
                              <span className="text-2xl font-medium">Duration: {product.duration}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </section>
        ))}

        <section className="mt-40 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-orange-500 via-orange-600 to-orange-500 transform -skew-y-6 z-0 animate-pulse-slow"></div>
          <div className="relative z-10 bg-white rounded-3xl shadow-2xl p-20 max-w-5xl mx-auto">
            <h2 className="text-7xl font-bold mb-16 text-orange-600 text-center">
              Contact Us
            </h2>
            <div className="space-y-10">
              <div className="group flex items-center gap-10 bg-gradient-to-r from-blue-50 to-blue-100 p-10 rounded-2xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
                <div className="bg-white p-6 rounded-2xl shadow-xl group-hover:shadow-2xl transition-all duration-500 group-hover:scale-110">
                  <img src="/telegram.svg" alt="Telegram" className="w-16 h-16" />
                </div>
                <a
                  href="https://t.me/RX_F5"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-3xl text-blue-600 hover:text-blue-700 font-bold hover:underline transition-all duration-300"
                >
                  t.me/RX_F5
                </a>
              </div>
              <div className="group flex items-center gap-10 bg-gradient-to-r from-indigo-50 to-indigo-100 p-10 rounded-2xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
                <div className="bg-white p-6 rounded-2xl shadow-xl group-hover:shadow-2xl transition-all duration-500 group-hover:scale-110">
                  <img src="/discord.svg" alt="Discord" className="w-16 h-16" />
                </div>
                <span className="text-3xl text-indigo-600 font-bold">fouad212.</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="mt-40 bg-gradient-to-r from-orange-600 via-orange-500 to-orange-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <p className="text-orange-100 text-2xl font-medium">
            © 2024 Orange Store. All rights reserved.
          </p>
        </div>
      </footer>

      <style>
        {`
          @keyframes fadeInUp {
            from {
              opacity: 0;
              transform: translateY(40px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }

          .animate-fade-in {
            animation: fadeIn 1.5s ease-out;
          }

          .animate-slide-up {
            animation: slideUp 1.2s ease-out;
          }

          @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }

          @keyframes slideUp {
            from {
              opacity: 0;
              transform: translateY(40px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }

          @keyframes glow {
            0%, 100% { text-shadow: 0 0 30px rgba(255,255,255,0.5); }
            50% { text-shadow: 0 0 50px rgba(255,255,255,0.8); }
          }

          .animate-glow {
            animation: glow 3s ease-in-out infinite;
          }

          .parallax-header {
            background-image: linear-gradient(rgba(234, 88, 12, 0.9), rgba(234, 88, 12, 0.9));
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
          }

          @keyframes float {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(5deg); }
          }

          .floating-shape {
            position: absolute;
            width: 300px;
            height: 300px;
            background: linear-gradient(45deg, rgba(255,255,255,0.1), rgba(255,255,255,0.2));
            border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
            animation: float 8s ease-in-out infinite;
          }

          .delay-2 {
            animation-delay: 2s;
            left: 60%;
            top: 20%;
          }

          .delay-4 {
            animation-delay: 4s;
            left: 20%;
            top: 30%;
          }

          @keyframes slide {
            from { background-position: 0 0; }
            to { background-position: 100% 100%; }
          }

          .animate-slide {
            animation: slide 60s linear infinite;
          }

          .animate-slide-reverse {
            animation: slide 40s linear infinite reverse;
          }

          .animate-pulse-slow {
            animation: pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite;
          }

          @keyframes pulse {
            0%, 100% {
              opacity: 1;
            }
            50% {
              opacity: .8;
            }
          }
        `}
      </style>
    </div>
  );
}
